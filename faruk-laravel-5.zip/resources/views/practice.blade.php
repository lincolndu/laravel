@extends('app')

@section('content')

db: coder_laravel
username: coder_lincoln 
pass: @r&b_WS4),sJ



@endsection