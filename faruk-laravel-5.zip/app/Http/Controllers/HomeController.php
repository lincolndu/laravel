<?php

namespace App\Http\Controllers;

use App\Register;
use App\Post;
use Illuminate\Http\Request;
use Session;
use DB;

class HomeController extends Controller {

    function index() {
        echo "it's home";
    }


}

?>